// Replace these two placeholders with values from Supabase Project Settings > API.
// The anon key is intended for browser use when Row Level Security is configured correctly.
window.TBN_CONFIG = {
  supabaseUrl: 'https://YOUR-PROJECT.supabase.co',
  supabaseAnonKey: 'YOUR_SUPABASE_ANON_KEY'
};
