create extension if not exists pgcrypto;

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  visitor_name text,
  visitor_email text,
  visitor_token uuid not null default gen_random_uuid(),
  status text not null default 'open' check (status in ('open','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender text not null check (sender in ('visitor','owner')),
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);

alter table public.conversations enable row level security;
alter table public.messages enable row level security;

-- Visitors can create a conversation and messages using a visitor token.
-- In production, use a server-side endpoint or Edge Function for stronger abuse controls.
create policy "visitor create conversations"
on public.conversations for insert to anon with check (true);

create policy "visitor read own conversation"
on public.conversations for select to anon
using (visitor_token = (current_setting('request.headers', true)::json->>'x-visitor-token')::uuid);

create policy "visitor create messages"
on public.messages for insert to anon
with check (
  sender = 'visitor' and exists (
    select 1 from public.conversations c
    where c.id = conversation_id
      and c.visitor_token = (current_setting('request.headers', true)::json->>'x-visitor-token')::uuid
  )
);

create policy "visitor read own messages"
on public.messages for select to anon
using (exists (
  select 1 from public.conversations c
  where c.id = conversation_id
    and c.visitor_token = (current_setting('request.headers', true)::json->>'x-visitor-token')::uuid
));

create policy "owner full conversations"
on public.conversations for all to authenticated using (true) with check (true);

create policy "owner full messages"
on public.messages for all to authenticated using (true) with check (true);

create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at);
create index if not exists conversations_updated_idx on public.conversations(updated_at desc);

alter table public.messages replica identity full;
alter table public.conversations replica identity full;
