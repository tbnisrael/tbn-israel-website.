# TBN Israel Stage 4 — Production-ready integration scaffold

This package connects the public chat and private admin dashboard through a Supabase backend.

## Setup
1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Create an owner account in Supabase Authentication.
4. Copy your Supabase project URL and anon key into `config.js`.
5. Host `index.html` and `admin.html` on your domain.
6. For real payments, connect Paystack using a server-side endpoint. Never put a Paystack secret key in browser JavaScript.

The included browser code is intentionally safe to publish with the Supabase anon key. Row Level Security limits access to conversations and messages.
